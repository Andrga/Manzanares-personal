<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="ground_ts" tilewidth="8" tileheight="8" tilecount="3" columns="3">
 <image source="../sprites/tileset.png" trans="000000" width="24" height="8"/>
</tileset>
