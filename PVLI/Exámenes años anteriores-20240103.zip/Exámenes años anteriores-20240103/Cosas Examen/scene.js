export default class Scene extends Phaser.Scene {
    constructor() {
        super({ key: 'Name' });
    }
    Infinity() {

    }
    preload() {

    }
    create() {

    }
    update(t, dt) {

    }
}